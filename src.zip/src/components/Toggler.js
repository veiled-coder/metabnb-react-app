import React, { Component } from "react";

export default class Toggler extends Component {
  state = {
    show: this.props.showValue,
  };
  toggle = () => {
    this.setState({
      show: !this.state.show,
    });
  };
  render() {
    // return <div>{this.props.renderprops(this.state.show, this.toggle)}</div>;
    return <div>{this.props.renderprops(this.state.show,this.toggle)}</div>;
  }
}
